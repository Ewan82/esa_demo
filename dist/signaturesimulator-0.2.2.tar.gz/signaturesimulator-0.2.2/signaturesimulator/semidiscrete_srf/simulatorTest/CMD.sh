for i in $(seq 1000) ; do ../semiD -srf s2a.srf $(cat OPTS1.txt) < test_angles.txt ; done
