'''
Main init module
'''
