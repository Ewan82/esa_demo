

class BackScatter:
    """Class to hold backscatter data for microwave RT model.
    """
    def __init__(self):
        self.hh = None
        self.vv = None
        self.hv = None