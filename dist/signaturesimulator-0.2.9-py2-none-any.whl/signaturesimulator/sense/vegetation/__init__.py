#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: __init__.py
# Author: "Thomas Weiß"
# Date:   2017-07-26 13:24:17
# Last Modified by:   "Thomas Weiß"
# Last Modified time: 2017-07-26 13:26:08

"""
Information about the content
"""



